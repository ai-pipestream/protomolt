SELECT p.preparation_bytes,p.preparation_sha256,p.owner_nonce,p.command_sha256,m.owner_nonce,
  CASE WHEN octet_length(m.modes::text)<=$1 THEN m.modes::text END
FROM repository_publication_preparations p
LEFT JOIN repository_publication_modes m USING(account_id,principal,operation_id,predecessor_generation)
WHERE p.account_id=$2 AND p.principal=$3 AND p.operation_id=$4 AND p.predecessor_generation=$5