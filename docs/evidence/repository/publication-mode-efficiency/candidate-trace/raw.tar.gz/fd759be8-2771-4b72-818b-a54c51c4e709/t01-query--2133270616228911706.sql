UPDATE repository_preparation_history_sets SET sealed=$5
WHERE account_id=$1 AND principal=$2 AND operation_id=$3 AND predecessor_generation=$4