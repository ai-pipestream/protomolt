SELECT octet_length(p.preparation_bytes), octet_length(m.modes::text)
FROM repository_publication_preparations p
LEFT JOIN repository_publication_modes m USING(account_id,principal,operation_id,predecessor_generation)
WHERE p.account_id=$1 AND p.principal=$2 AND p.operation_id=$3 AND p.predecessor_generation=$4