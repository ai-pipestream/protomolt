SELECT encode(a.artifact_sha256,'hex'),a.size_bytes,
    CASE WHEN a.size_bytes BETWEEN 1 AND 16777216 THEN a.artifact_bytes END
FROM document_assessment_artifacts r JOIN repository_schema_artifacts a USING(account_id,artifact_sha256)
WHERE r.assessment_id=$1 AND r.account_id=$2
  AND (SELECT COALESCE(sum(a2.size_bytes),0) FROM document_assessment_artifacts r2
       JOIN repository_schema_artifacts a2 USING(account_id,artifact_sha256)
       WHERE r2.assessment_id=$3 AND r2.account_id=$4)=$5
ORDER BY a.artifact_sha256 LIMIT 65