INSERT INTO repository_preparation_coverage_certificates(account_id,principal,operation_id,
    predecessor_generation,preparation_sha256,command_sha256,root_count,roots_sha256,verifier_version,proof_kind)
VALUES($1,$2,$3,$4,$5,$6,$7,$8,1,$9)