SELECT EXISTS(SELECT 1 FROM document_operation_selections
  WHERE account_id=$1 AND principal=$2 AND operation_id=$3 AND owner_generation=$4)