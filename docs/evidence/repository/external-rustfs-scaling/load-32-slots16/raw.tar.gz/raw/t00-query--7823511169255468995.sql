SELECT p.revision_ordinal,p.part,p.sub_key,o.expected_size,o.expected_sha256,
 a.account_id=$1 AND a.state='VERIFIED' AND o.verified
 AND o.part=p.part AND o.sub_key=p.sub_key
 AND a.backend_generation=l.backend_generation AND a.storage_realm=l.storage_realm
 AND a.storage_namespace=l.storage_namespace AND o.storage_realm=l.storage_realm
 AND o.storage_namespace=l.storage_namespace AND o.object_key=l.object_key AS qualified
FROM document_revision_parts p LEFT JOIN repository_physical_locations l
 ON l.object_id=p.object_id AND l.source_kind='DOCUMENT_PART'
LEFT JOIN document_part_attempt_objects o ON o.physical_object_id=l.object_id
 AND o.attempt_id=l.source_id AND o.ordinal=l.source_ordinal
LEFT JOIN document_part_attempts a ON a.attempt_id=o.attempt_id
WHERE p.revision_id=$2
ORDER BY p.revision_ordinal