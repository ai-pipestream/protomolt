INSERT INTO document_revision_commits(revision_id,node_id,publication_revision,account_id,principal,operation_id,
    owner_generation,member_id,member_ordinal,selection_revision,event_id,metadata_version,admission_mode,structured_resolution)
VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,1,$12,$13)