WITH snapshots AS MATERIALIZED (
SELECT document_publication_body(d) AS body,document_revision_metadata_v1(d) AS metadata
FROM jsonb_populate_record(NULL::documents,jsonb_build_object(
  'node_id',CAST($1 AS uuid),'account_id',CAST($2 AS text),
  'doc_id',CAST($3 AS text),'graph_id',CAST($4 AS text),'graph_address_id',CAST($5 AS text),
  'drive_name',CAST($6 AS text),'object_key',CAST($7 AS text),'version_id',CAST($8 AS text),
  'etag',CAST($9 AS text),'size_bytes',CAST($10 AS bigint),'checksum',CAST($11 AS text),
  'part_manifest',CAST($12 AS jsonb),'row_kind',CAST($13 AS text),'cluster_id',CAST($14 AS text),
  'datasource_id',CAST($15 AS text),'connector_id',CAST($16 AS text),
  'content_type',CAST($17 AS text),'filename',CAST($18 AS text),'security',CAST($19 AS jsonb),
  'delete_source_blobs_on_settle',CAST($20 AS boolean),'source_blob_delete_reason',CAST($21 AS text),
  'crawl_id',CAST($22 AS text),'created_at',CAST($23 AS timestamptz),'updated_at',CAST($24 AS timestamptz)
)) d)
SELECT CASE WHEN octet_length(body::text)<=16777216 THEN body::text END,
       CASE WHEN octet_length(metadata::text)<=1048576 THEN metadata::text END FROM snapshots