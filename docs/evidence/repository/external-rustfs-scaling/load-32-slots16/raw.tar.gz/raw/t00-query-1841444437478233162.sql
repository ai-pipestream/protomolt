INSERT INTO repository_preparation_history_sets(account_id,principal,operation_id,predecessor_generation,
  preparation_sha256,command_sha256,expected_count,roots_sha256)
VALUES($1,$2,$3,$4,$5,$6,$7,$8)