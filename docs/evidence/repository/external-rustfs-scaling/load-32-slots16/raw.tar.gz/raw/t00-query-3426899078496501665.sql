SELECT h.preparation_sha256,h.command_sha256,h.expected_count,h.roots_sha256,h.sealed,
  actual.root_count,actual.root_digest
FROM repository_preparation_history_sets h
CROSS JOIN LATERAL (
  SELECT count(*) AS root_count,
    sha256(convert_to('protomolt/preparation-history/v1' || chr(10) ||
      coalesce(string_agg(r.node_id::text || '/' || r.revision_id::text || chr(10),''
        ORDER BY r.node_id,r.revision_id),''),'UTF8')) AS root_digest
  FROM repository_preparation_history_roots r
  WHERE r.account_id=h.account_id AND r.principal=h.principal AND r.operation_id=h.operation_id
    AND r.predecessor_generation=h.predecessor_generation
) actual
WHERE h.account_id=$1 AND h.principal=$2 AND h.operation_id=$3 AND h.predecessor_generation=$4