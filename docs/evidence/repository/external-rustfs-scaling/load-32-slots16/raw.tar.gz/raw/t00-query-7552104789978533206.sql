SELECT l.object_id,o.part,o.sub_key,l.object_key,o.expected_size,o.expected_sha256,o.content_type,
    o.provider_version,o.etag,l.backend_generation,l.storage_realm,l.storage_namespace
FROM repository_physical_locations l JOIN document_part_attempt_objects o
    ON o.attempt_id=l.source_id AND o.ordinal=l.source_ordinal AND o.physical_object_id=l.object_id
JOIN document_part_attempts a ON a.attempt_id=o.attempt_id
JOIN repository_object_retention r USING(object_id)
WHERE l.object_id=ANY(CAST($1 AS uuid[])) AND l.source_kind='DOCUMENT_PART' AND a.account_id=$2
    AND a.state='VERIFIED' AND o.verified AND NOT r.retiring AND NOT r.reclaiming
    AND o.object_key=l.object_key AND o.storage_realm=l.storage_realm AND o.storage_namespace=l.storage_namespace
    AND a.backend_generation=l.backend_generation AND a.storage_realm=l.storage_realm
    AND NOT EXISTS(SELECT 1 FROM document_part_attempt_cleanup c WHERE c.attempt_id=a.attempt_id)