WITH locked AS MATERIALIZED (
    SELECT object_id,retiring,reclaiming FROM repository_object_retention
    WHERE object_id=ANY(CAST($1 AS uuid[])) ORDER BY object_id FOR UPDATE
) SELECT count(*),COALESCE(bool_or(retiring OR reclaiming),false) FROM locked