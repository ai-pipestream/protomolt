NOT EXISTS(SELECT 1 FROM repository_preparation_coverage_certificates c
  WHERE c.account_id=NEW.account_id AND c.principal=NEW.principal AND c.operation_id=NEW.operation_id
   AND c.predecessor_generation=NEW.predecessor_generation AND c.preparation_sha256=NEW.preparation_sha256
   AND c.command_sha256=NEW.command_sha256 AND c.proof_kind='LIVE_ROOTS')
  OR EXISTS(SELECT 1 FROM repository_preparation_coverage_unresolved u WHERE u.account_id=NEW.account_id
   AND u.principal=NEW.principal AND u.operation_id=NEW.operation_id AND u.predecessor_generation=NEW.predecessor_generation)