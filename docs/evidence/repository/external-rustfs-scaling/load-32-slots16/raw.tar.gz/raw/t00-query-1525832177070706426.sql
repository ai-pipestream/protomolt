SELECT NOT EXISTS (
  SELECT 1 FROM repository_publication_preparations WHERE account_id=$1 AND principal=$2
    AND operation_id=$3 AND predecessor_generation=$4
) OR EXISTS (
  SELECT 1 FROM repository_publication_preparations preparation
  JOIN repository_publication_modes modes USING(account_id,principal,operation_id,predecessor_generation)
  WHERE preparation.account_id=$5 AND preparation.principal=$6 AND preparation.operation_id=$7
    AND preparation.predecessor_generation=$8 AND preparation.owner_nonce=$9
    AND modes.owner_nonce=$10 AND preparation.command_sha256=$11
    AND modes.modes=CAST($12 AS jsonb)
)