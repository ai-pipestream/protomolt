SELECT type_url,encode(descriptor_sha256,'hex'),metadata_codec,metadata_version,
 encode(metadata_sha256,'hex'),encode(source_sha256,'hex'),account_id
FROM document_revision_schema_assets WHERE revision_id=$1
ORDER BY type_url_sha256,descriptor_sha256 LIMIT 65