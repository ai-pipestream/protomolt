SELECT encode(a.artifact_sha256,'hex'),a.artifact_bytes FROM document_revision_schema_artifacts r
JOIN repository_schema_artifacts a ON a.account_id=r.account_id AND a.artifact_sha256=r.artifact_sha256
WHERE r.revision_id=$1 AND r.account_id=$2 ORDER BY a.artifact_sha256 LIMIT 65