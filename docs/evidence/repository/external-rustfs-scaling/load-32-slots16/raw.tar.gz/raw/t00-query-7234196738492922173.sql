NEW.expected_count>0 AND NOT EXISTS(SELECT 1 FROM repository_preparation_pin_batches
  WHERE account_id=NEW.account_id AND principal=NEW.principal AND operation_id=NEW.operation_id
   AND predecessor_generation=NEW.predecessor_generation AND initial_capture AND sealed
   AND creation_xid=NEW.creation_xid)