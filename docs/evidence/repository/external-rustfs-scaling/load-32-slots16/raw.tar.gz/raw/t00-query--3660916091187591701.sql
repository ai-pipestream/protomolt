SELECT c.member_id,c.member_ordinal,c.node_id,c.revision_id,c.publication_revision,c.owner_generation,
    r.projection_sealed,r.native_binding
FROM document_revision_commits c JOIN document_revision_publications r USING(revision_id)
WHERE c.account_id=$1 AND c.principal=$2 AND c.operation_id=$3
ORDER BY c.member_ordinal LIMIT 65