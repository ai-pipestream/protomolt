NOT EXISTS(SELECT 1 FROM repository_preparation_history_sets
  WHERE account_id=NEW.account_id AND principal=NEW.principal AND operation_id=NEW.operation_id
   AND predecessor_generation=NEW.predecessor_generation AND sealed)