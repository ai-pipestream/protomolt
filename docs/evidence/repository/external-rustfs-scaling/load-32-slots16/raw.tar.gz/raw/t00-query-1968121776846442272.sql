SELECT revision_ordinal,encode(root_locator_sha256,'hex'),encode(fragment_sha256,'hex'),fragment_size,
 evidence_codec,evidence_version,evidence_bytes,encode(evidence_sha256,'hex')
FROM document_revision_schema_evidence WHERE revision_id=$1
ORDER BY revision_ordinal,root_locator_sha256 LIMIT 1025