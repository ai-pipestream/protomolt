SELECT attempt_id,revision_ordinal,physical_object_id FROM document_part_attempt_objects
WHERE attempt_id=ANY(CAST($1 AS uuid[])) LIMIT 10001