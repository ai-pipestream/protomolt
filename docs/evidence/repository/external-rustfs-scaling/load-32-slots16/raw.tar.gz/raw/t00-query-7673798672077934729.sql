SELECT a.member_id,a.node_id,a.sampled_revision,a.drive_id,a.backend_generation,a.storage_realm,
    a.storage_namespace,a.upload_count,h.selection_revision,h.attempt_id,
    a.drive_sha256=document_operation_drive_digest_v1(d)
FROM document_operation_selections a JOIN document_operation_selection_current c
    USING(account_id,principal,operation_id,owner_generation,member_id)
JOIN document_operation_selection_attempts h
    USING(account_id,principal,operation_id,owner_generation,member_id,selection_revision)
JOIN drives d ON d.drive_id=a.drive_id
WHERE a.account_id=$1 AND a.principal=$2 AND a.operation_id=$3 AND a.owner_generation=$4
LIMIT 65