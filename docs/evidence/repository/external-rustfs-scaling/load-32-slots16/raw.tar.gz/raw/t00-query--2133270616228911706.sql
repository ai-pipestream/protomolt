UPDATE repository_preparation_history_sets SET sealed=true
WHERE account_id=$1 AND principal=$2 AND operation_id=$3 AND predecessor_generation=$4