INSERT INTO repository_operation_owners(account_id,principal,operation_id,owner_token,owner_generation,lease_until)
VALUES ($1,$2,$3,$4,1,clock_timestamp()+($5 * interval '1 millisecond'))