SELECT o.assessment_id FROM document_assessment_owners o
WHERE o.assessment_id=$1 AND o.account_id=$2 AND o.principal=$3
    AND o.operation_id=$4 AND o.owner_generation=$5
    AND o.command_codec=$6 AND o.command_version=$7
    AND encode(o.command_sha256,'hex')=$8 AND encode(o.manifest_sha256,'hex')=$9
    AND o.sealed AND o.release_xid IS NULL AND o.retain_until=$10
    AND o.retain_until>clock_timestamp()
FOR SHARE OF o