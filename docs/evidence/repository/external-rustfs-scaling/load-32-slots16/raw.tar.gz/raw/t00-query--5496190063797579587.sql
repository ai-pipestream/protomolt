SELECT DISTINCT object_id FROM document_revision_parts
WHERE revision_id=ANY(CAST($1 AS uuid[])) LIMIT 10001