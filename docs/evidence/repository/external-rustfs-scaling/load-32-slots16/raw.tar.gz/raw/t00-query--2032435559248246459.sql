repository_successor_preparation(NEW.account_id,NEW.principal,NEW.operation_id,
  NEW.predecessor_generation,NEW.owner_nonce,NEW.command_sha256,NEW.preparation_sha256)
  AND EXISTS(SELECT 1 FROM repository_preparation_coverage_unresolved u WHERE u.account_id=NEW.account_id
   AND u.principal=NEW.principal AND u.operation_id=NEW.operation_id AND u.predecessor_generation=NEW.predecessor_generation)
  AND NOT EXISTS(SELECT 1 FROM repository_preparation_history_sets h WHERE h.account_id=NEW.account_id
   AND h.principal=NEW.principal AND h.operation_id=NEW.operation_id AND h.predecessor_generation=NEW.predecessor_generation)
  AND NOT EXISTS(SELECT 1 FROM repository_preparation_coverage_certificates c WHERE c.account_id=NEW.account_id
   AND c.principal=NEW.principal AND c.operation_id=NEW.operation_id AND c.predecessor_generation=NEW.predecessor_generation)