UPDATE repository_execution_claims SET lease_until=GREATEST(lease_until,
    clock_timestamp()+($1 * interval $7)),fence_epoch=$2,fence_token=$3
WHERE account_id=$4 AND principal=$5 AND operation_id=$6