SELECT lease_until > clock_timestamp(), EXISTS(SELECT $4 FROM repository_operation_success s
    WHERE s.account_id=o.account_id AND s.principal=o.principal AND s.operation_id=o.operation_id)
    OR EXISTS(SELECT $5 FROM repository_operation_rejection r
    WHERE r.account_id=o.account_id AND r.principal=o.principal AND r.operation_id=o.operation_id)
FROM repository_operation_owners o
WHERE o.account_id=$1 AND o.principal=$2 AND o.operation_id=$3