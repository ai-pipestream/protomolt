SELECT encode(r.artifact_sha256,'hex'),a.size_bytes,encode(sha256(a.artifact_bytes),'hex')
FROM document_assessment_artifacts r JOIN repository_schema_artifacts a USING(account_id,artifact_sha256)
WHERE r.assessment_id=$1 LIMIT 65