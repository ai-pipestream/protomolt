INSERT INTO repository_operation_rejection(account_id,principal,operation_id,owner_generation,
    command_codec,command_version,command_sha256,result_codec,result_version,result_bytes,result_sha256,
    recorded_at_epoch_micros,disposition,reason,assessment_id,manifest_codec,manifest_version,manifest_sha256,retain_until_epoch_micros)
SELECT $1,$2,$3,$4,$5,$6,$7,
    $8,$9,$10,$11,$12,1,2,$13,$14,$15,$16,$17
WHERE $18-floor(extract(epoch FROM clock_timestamp())*1000000)>=$19