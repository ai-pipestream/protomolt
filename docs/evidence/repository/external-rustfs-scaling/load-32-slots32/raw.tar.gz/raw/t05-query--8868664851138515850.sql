SELECT member_id,revision_ordinal,evidence_codec,evidence_version,encode(evidence_sha256,'hex'),
    encode(fragment_sha256,'hex'),fragment_size,evidence_size,encode(sha256(evidence_bytes),'hex')
FROM document_assessment_roots WHERE assessment_id=$1 LIMIT 4097