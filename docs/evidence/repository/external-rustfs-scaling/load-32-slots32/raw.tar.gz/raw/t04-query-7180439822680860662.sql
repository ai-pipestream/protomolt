SELECT share_repository_retention_set(ARRAY(
    SELECT object_id FROM document_assessment_objects WHERE assessment_id=$1 LIMIT 10001))