SELECT assessment_id FROM document_assessment_owners
WHERE assessment_id=$1 AND account_id=$2 AND principal=$3
    AND operation_id=$4 AND owner_generation=$5 AND command_codec=$6 AND command_version=$7
    AND encode(command_sha256,'hex')=$8 AND encode(manifest_sha256,'hex')=$9
    AND sealed AND release_xid IS NULL AND retain_until=$10 FOR SHARE