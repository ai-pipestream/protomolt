SELECT assessment_id,command_codec,command_version,encode(command_sha256,'hex'),
    encode(manifest_sha256,'hex'),CAST(floor(extract(epoch FROM retain_until)*1000000) AS bigint),
    sealed AND release_xid IS NULL AND retain_until>clock_timestamp()
FROM document_assessment_owners WHERE account_id=$1 AND principal=$2
    AND operation_id=$3 AND owner_generation=$4 LIMIT 2 FOR UPDATE