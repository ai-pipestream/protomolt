SELECT assessment_id,command_codec,command_version,encode(command_sha256,'hex'),
    sealed,release_xid IS NULL,retain_until=$1,retain_until>clock_timestamp(),
    expected_slots,expected_artifacts,expected_roots,encode(manifest_sha256,'hex'),
    octet_length(manifest_bytes)
FROM document_assessment_owners WHERE account_id=$2 AND principal=$3
    AND operation_id=$4 AND owner_generation=$5 FOR UPDATE