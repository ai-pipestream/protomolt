UPDATE repository_operation_owners SET lease_until=GREATEST(lease_until,
    clock_timestamp()+($1 * interval $5))
WHERE account_id=$2 AND principal=$3 AND operation_id=$4
  AND lease_until > clock_timestamp()