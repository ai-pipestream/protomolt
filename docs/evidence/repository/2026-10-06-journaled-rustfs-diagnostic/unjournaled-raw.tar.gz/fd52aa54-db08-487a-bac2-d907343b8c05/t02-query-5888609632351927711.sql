SELECT EXISTS(SELECT $12 FROM repository_operation_owners
    WHERE account_id=$1 AND principal=$2 AND operation_id=$3
        AND owner_generation=$4 AND owner_token=$5 AND lease_until>clock_timestamp()),
    EXISTS(SELECT $13 FROM repository_operation_success
        WHERE account_id=$6 AND principal=$7 AND operation_id=$8)
    OR EXISTS(SELECT $14 FROM repository_operation_rejection
        WHERE account_id=$9 AND principal=$10 AND operation_id=$11)