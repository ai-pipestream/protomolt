INSERT INTO document_assessment_slots(assessment_id,member_id,revision_ordinal,selection_revision,
    object_id,declaration,source_revision,source_ordinal) VALUES($1,$2,$3,$4,$5,$6,$7,$8)