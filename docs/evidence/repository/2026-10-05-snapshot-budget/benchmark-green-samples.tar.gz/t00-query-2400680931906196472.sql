SELECT s.member_id,s.revision_ordinal,s.selection_revision,s.object_id,s.declaration,s.source_revision,s.source_ordinal,
    h.attempt_id,o.attempt_id,o.revision_ordinal,o.part,o.sub_key,o.expected_size,o.expected_sha256,o.content_type,
    l.object_key,l.backend_generation,l.storage_realm,l.storage_namespace,o.verified,
    EXISTS(SELECT $10 FROM document_assessment_objects x WHERE x.assessment_id=s.assessment_id AND x.object_id=s.object_id),
    EXISTS(SELECT $11 FROM repository_object_references r WHERE r.object_id=s.object_id
        AND r.owner_kind=$12 AND r.owner_id=s.assessment_id AND r.owner_revision=$13),o.provider_version,
    a.operation_principal=$1 AND a.operation_id=$2 AND a.operation_generation=$3
        AND a.member_id=s.member_id AND a.plan_kind=$14
        AND a.backend_generation=anchor.backend_generation AND a.storage_realm=anchor.storage_realm
        AND a.storage_namespace=anchor.storage_namespace,
    anchor.drive_id,anchor.node_id,anchor.sampled_revision,anchor.upload_count
FROM document_assessment_slots s
JOIN document_operation_selection_attempts h ON h.account_id=$4 AND h.principal=$5
    AND h.operation_id=$6 AND h.owner_generation=$7
    AND h.member_id=s.member_id AND h.selection_revision=s.selection_revision
JOIN document_operation_selections anchor ON anchor.account_id=h.account_id AND anchor.principal=h.principal
    AND anchor.operation_id=h.operation_id AND anchor.owner_generation=h.owner_generation AND anchor.member_id=h.member_id
JOIN repository_physical_locations l ON l.object_id=s.object_id AND l.source_kind=$15
JOIN document_part_attempt_objects o ON o.attempt_id=l.source_id AND o.ordinal=l.source_ordinal
    AND o.physical_object_id=l.object_id
    AND o.object_key=l.object_key AND o.storage_realm=l.storage_realm AND o.storage_namespace=l.storage_namespace
JOIN document_part_attempts a ON a.attempt_id=o.attempt_id AND a.account_id=$8
    AND a.backend_generation=l.backend_generation AND a.storage_realm=l.storage_realm AND a.storage_namespace=l.storage_namespace
WHERE s.assessment_id=$9 LIMIT $16