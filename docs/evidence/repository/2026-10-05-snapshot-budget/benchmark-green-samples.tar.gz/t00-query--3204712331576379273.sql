SELECT assessment_id,command_codec,command_version,encode(command_sha256,$6),
    sealed,release_xid IS NULL,retain_until=$1,retain_until>clock_timestamp(),
    expected_slots,expected_artifacts,expected_roots,encode(manifest_sha256,$7),
    CASE WHEN octet_length(manifest_bytes) BETWEEN $8 AND $9 THEN manifest_bytes END
FROM document_assessment_owners WHERE account_id=$2 AND principal=$3
    AND operation_id=$4 AND owner_generation=$5 FOR UPDATE