SELECT CASE WHEN octet_length(manifest_bytes)=$1 THEN manifest_bytes END
FROM document_assessment_owners WHERE assessment_id=$2