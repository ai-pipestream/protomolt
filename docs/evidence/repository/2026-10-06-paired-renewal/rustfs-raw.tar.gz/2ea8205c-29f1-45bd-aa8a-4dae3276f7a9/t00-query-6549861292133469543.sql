SELECT r.native_binding,r.projection_sealed,c.account_id,c.admission_mode,a.decision,
 (c.node_id=r.node_id AND a.node_id=r.node_id AND a.account_id=c.account_id
  AND a.principal=c.principal AND a.operation_id=c.operation_id AND a.owner_generation=c.owner_generation
  AND a.member_id=c.member_id AND a.selection_revision=c.selection_revision
  AND c.publication_revision=r.publication_revision AND s.command_sha256=a.command_sha256
  AND a.creation_xid=c.creation_xid AND c.creation_xid=r.projection_xid
  AND s.creation_xid=c.creation_xid AND a.metadata=c.metadata_snapshot AND a.body=r.body
  AND s.command_codec=$3 AND s.command_version=$4),
 a.container_type_url_sha256,a.container_descriptor_sha256,
 octet_length(o.command),octet_length(p.policy_bytes)
FROM document_revision_publications r
LEFT JOIN document_revision_commits c ON c.revision_id=r.revision_id
LEFT JOIN document_revision_schema_admissions a ON a.revision_id=r.revision_id
LEFT JOIN repository_operation_success s ON s.account_id=c.account_id AND s.principal=c.principal
 AND s.operation_id=c.operation_id AND s.owner_generation=c.owner_generation
LEFT JOIN repository_operations o ON o.account_id=c.account_id AND o.principal=c.principal AND o.operation_id=c.operation_id
LEFT JOIN document_schema_policies p ON p.account_id=a.account_id AND p.policy_sha256=a.policy_sha256
WHERE r.revision_id=$1 AND r.node_id=$2