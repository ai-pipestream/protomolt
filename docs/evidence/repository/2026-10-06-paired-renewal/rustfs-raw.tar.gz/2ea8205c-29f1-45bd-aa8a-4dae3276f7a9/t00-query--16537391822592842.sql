INSERT INTO document_part_attempt_objects(attempt_id,ordinal,revision_ordinal,part,sub_key,storage_realm,storage_namespace,
    object_key,expected_size,expected_sha256,content_type)
SELECT $1,p.ordinal,p.revision_ordinal,p.part,p.sub_key,$2,$3,p.object_key,p.expected_size,p.expected_sha256,p.content_type
FROM jsonb_to_recordset(CAST($4 AS jsonb)) AS p(ordinal integer,revision_ordinal integer,part integer,sub_key text,
    object_key text,expected_size bigint,expected_sha256 text,content_type text)
ORDER BY p.ordinal