SELECT count(*)=$1 FROM jsonb_to_recordset(CAST($2 AS jsonb)) q(member text,revision bigint,attempt uuid,token uuid)
JOIN document_operation_selection_current c ON c.member_id=q.member AND c.selection_revision=q.revision
JOIN document_operation_selection_attempts h USING(account_id,principal,operation_id,owner_generation,member_id,selection_revision)
JOIN document_part_attempts a ON a.attempt_id=h.attempt_id AND a.attempt_id=q.attempt AND a.lease_token=q.token
WHERE c.account_id=$3 AND c.principal=$4 AND c.operation_id=$5 AND c.owner_generation=$6
  AND a.plan_kind='NEW_CONTENT' AND a.state IN ('STAGING','VERIFIED') AND a.lease_until>clock_timestamp()
  AND NOT EXISTS(SELECT 1 FROM document_part_attempt_cleanup WHERE attempt_id=a.attempt_id)