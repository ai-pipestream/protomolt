SELECT r.object_id FROM repository_object_retention r WHERE r.object_id IN (
 SELECT q.object FROM jsonb_to_recordset(CAST($1 AS jsonb)) q(object uuid))
ORDER BY r.object_id FOR SHARE OF r