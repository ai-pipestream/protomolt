SELECT owner_token FROM repository_operation_owners
WHERE account_id=$1 AND principal=$2 AND operation_id=$3
    AND owner_generation=$4 AND owner_token=$5 FOR SHARE