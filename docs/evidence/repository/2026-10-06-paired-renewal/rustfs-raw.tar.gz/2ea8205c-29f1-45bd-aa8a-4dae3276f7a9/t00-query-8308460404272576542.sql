SELECT owner_generation,result_codec,result_version,result_bytes,encode(result_sha256,'hex')
FROM repository_operation_success
WHERE account_id=$1 AND principal=$2 AND operation_id=$3