SELECT command_codec,command_version,command,command_sha256 FROM repository_operations
WHERE account_id=$1 AND principal=$2 AND operation_id=$3