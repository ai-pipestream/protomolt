UPDATE repository_operation_owners SET write_fence_xid=pg_current_xact_id()
WHERE account_id=$1 AND principal=$2 AND operation_id=$3
  AND owner_generation=$4 AND owner_token=$5 AND lease_until > clock_timestamp()
RETURNING owner_token,owner_generation,lease_until