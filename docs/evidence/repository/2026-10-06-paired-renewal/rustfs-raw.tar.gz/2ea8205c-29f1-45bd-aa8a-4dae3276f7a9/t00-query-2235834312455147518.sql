INSERT INTO document_assessment_artifacts(assessment_id,account_id,artifact_sha256)
SELECT $1,account_id,artifact_sha256 FROM repository_schema_artifacts
WHERE account_id=$2 AND artifact_sha256=$3 AND size_bytes=$4