SELECT DISTINCT s.member_id,s.selection_revision,h.attempt_id
FROM document_assessment_slots s JOIN document_operation_selection_attempts h
  ON h.account_id=$1 AND h.principal=$2 AND h.operation_id=$3 AND h.owner_generation=$4
  AND h.member_id=s.member_id AND h.selection_revision=s.selection_revision
WHERE s.assessment_id=$5 AND h.attempt_id IS NOT NULL LIMIT $6