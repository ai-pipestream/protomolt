SELECT EXISTS(SELECT 1 FROM document_operation_selection_current c
    JOIN document_operation_selection_attempts h USING(account_id,principal,operation_id,owner_generation,member_id,selection_revision)
    JOIN document_part_attempts a ON a.attempt_id=h.attempt_id
    WHERE c.account_id=$1 AND c.principal=$2 AND c.operation_id=$3
      AND c.owner_generation=$4 AND c.member_id=$5 AND c.selection_revision=$6
      AND h.attempt_id=$7 AND a.lease_until>clock_timestamp()
      AND NOT EXISTS(SELECT 1 FROM document_part_attempt_cleanup WHERE attempt_id=a.attempt_id))