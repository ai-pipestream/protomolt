SELECT generation,provider,endpoint,region,path_style,storage_realm,identity_schema,CAST(identity_json AS text)
FROM managed_backend_profiles WHERE generation IN ($1)