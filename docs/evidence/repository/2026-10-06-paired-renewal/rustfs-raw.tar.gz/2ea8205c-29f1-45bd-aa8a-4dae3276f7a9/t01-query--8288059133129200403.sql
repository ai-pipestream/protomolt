SELECT owner_nonce, CASE WHEN octet_length(modes::text)<=1048576 THEN modes::text END
FROM repository_publication_modes
WHERE account_id=$1 AND principal=$2 AND operation_id=$3 AND predecessor_generation=$4