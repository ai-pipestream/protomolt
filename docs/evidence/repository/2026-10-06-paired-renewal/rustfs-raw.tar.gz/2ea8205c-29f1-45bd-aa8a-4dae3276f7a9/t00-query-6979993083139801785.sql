SELECT d.node_id,d.account_id,d.doc_id,d.graph_id,d.graph_address_id,
    d.mutation_revision,d.status,d.pending_purge_id,d.security::text
FROM unnest(CAST($1 AS uuid[])) WITH ORDINALITY AS requested(id,position)
JOIN documents d ON d.node_id=requested.id
ORDER BY requested.position FOR SHARE OF d