SELECT member_id,revision_ordinal,evidence_codec,evidence_version,encode(evidence_sha256,$2),
    encode(fragment_sha256,$3),fragment_size,evidence_size,encode(sha256(evidence_bytes),$4)
FROM document_assessment_roots WHERE assessment_id=$1 LIMIT $5