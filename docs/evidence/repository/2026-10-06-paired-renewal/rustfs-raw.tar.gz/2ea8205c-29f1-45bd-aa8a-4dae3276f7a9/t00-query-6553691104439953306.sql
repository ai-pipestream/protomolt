INSERT INTO document_revision_schema_assets
(revision_id,account_id,principal,operation_id,owner_generation,type_url,type_url_sha256,
 descriptor_sha256,metadata_sha256,metadata_codec,metadata_version,source_sha256)
VALUES($1,$2,$3,$4,$5,$6,sha256(convert_to($7,'UTF8')),$8,$9,$10,$11,$12)