SELECT encode(r.artifact_sha256,$2),a.size_bytes,encode(sha256(a.artifact_bytes),$3)
FROM document_assessment_artifacts r JOIN repository_schema_artifacts a USING(account_id,artifact_sha256)
WHERE r.assessment_id=$1 LIMIT $4