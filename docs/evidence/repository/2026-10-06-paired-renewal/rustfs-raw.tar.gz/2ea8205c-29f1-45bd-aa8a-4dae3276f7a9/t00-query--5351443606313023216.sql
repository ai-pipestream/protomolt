SELECT c.member_id,c.node_id FROM document_revision_commits c
JOIN document_revision_publications r USING(revision_id)
WHERE c.revision_id=$1 AND c.account_id=$2 AND c.principal=$3
 AND c.operation_id=$4 AND c.owner_generation=$5
 AND c.creation_xid=pg_current_xact_id() AND r.projection_xid=pg_current_xact_id()
 AND r.native_binding=c.revision_id AND NOT r.projection_sealed