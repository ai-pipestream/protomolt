INSERT INTO document_assessment_read_sessions(session_id,reader_incarnation,assessment_id)
VALUES($1,$2,$3)