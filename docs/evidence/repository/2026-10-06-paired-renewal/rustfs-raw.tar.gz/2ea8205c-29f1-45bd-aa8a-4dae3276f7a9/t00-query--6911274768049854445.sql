SELECT sealed AND release_xid IS NULL AND retain_until>clock_timestamp()
FROM document_assessment_owners WHERE assessment_id=$1