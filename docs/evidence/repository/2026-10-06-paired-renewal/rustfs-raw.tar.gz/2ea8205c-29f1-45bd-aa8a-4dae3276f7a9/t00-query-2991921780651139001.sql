UPDATE document_part_attempts SET state='VERIFIED' WHERE attempt_id=$1 AND state='STAGING'
  AND NOT EXISTS(SELECT 1 FROM document_part_attempt_objects WHERE attempt_id=$2 AND NOT verified)