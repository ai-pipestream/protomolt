SELECT snapshot_codec,snapshot_version,
    CASE WHEN octet_length(snapshot_bytes)=$1 THEN snapshot_bytes END,encode(snapshot_sha256,$3)
FROM document_assessment_slot_snapshots WHERE assessment_id=$2