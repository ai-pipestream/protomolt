INSERT INTO document_revision_parts(revision_id,revision_ordinal,part,sub_key,object_id)
SELECT $1,q.ordinal,q.part,q.sub_key,q.object_id
FROM jsonb_to_recordset(CAST($2 AS jsonb)) q(ordinal integer,part integer,sub_key text,object_id uuid)