SELECT EXISTS(SELECT $20 FROM document_assessment_read_sessions WHERE session_id=identity.session_id
  AND reader_incarnation=identity.reader_incarnation AND assessment_id=identity.assessment_id)