INSERT INTO document_operation_selections(account_id,principal,operation_id,owner_generation,
    member_id,node_id,sampled_revision,drive_id,drive_snapshot,drive_sha256,backend_generation,
    storage_realm,storage_namespace,upload_count,attempt_id)
SELECT $1,$2,$3,$4,q.member_id,q.node_id,q.sampled_revision,
    q.drive_id,document_operation_drive_snapshot(d),document_operation_drive_digest_v1(d),
    q.backend_generation,q.storage_realm,q.storage_namespace,
    q.upload_count,q.attempt_id
FROM jsonb_to_recordset(CAST($5 AS jsonb)) q(member_id text,node_id uuid,sampled_revision bigint,
    drive_id uuid,backend_generation text,storage_realm text,storage_namespace text,
    upload_count integer,attempt_id uuid)
JOIN drives d ON d.drive_id=q.drive_id
ORDER BY q.member_id