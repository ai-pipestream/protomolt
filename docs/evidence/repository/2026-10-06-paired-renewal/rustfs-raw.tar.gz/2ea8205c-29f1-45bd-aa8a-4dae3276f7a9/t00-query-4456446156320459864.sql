SELECT r.publication_revision,r.native_binding,r.projection_sealed,
 (c.node_id=r.node_id AND c.account_id=$1 AND c.publication_revision=r.publication_revision
  AND c.creation_xid=r.projection_xid AND s.creation_xid=c.creation_xid),
 octet_length((r.body->$10)::text),
 CASE WHEN octet_length((r.body->$11)::text)<=$2 THEN (r.body->$12)::text END,
 r.body->>$13,r.body->>$14,r.body->>$15,r.body->>$16,
 (r.body->>$17=CAST(r.node_id AS text) AND r.body->>$18=$3
  AND r.body->>$19=$4 AND r.body->>$20=$5 AND r.body->>$21=$6),
 (SELECT count(*) FROM document_revision_parts p WHERE p.revision_id=r.revision_id),
 c.metadata_version,octet_length(c.metadata_snapshot::text),
 CASE WHEN octet_length(c.metadata_snapshot::text)<=$7 THEN c.metadata_snapshot::text END
FROM document_revision_publications r
LEFT JOIN document_revision_commits c ON c.revision_id=r.revision_id
LEFT JOIN repository_operation_success s USING(account_id,principal,operation_id,owner_generation)
WHERE r.revision_id=$8 AND r.node_id=$9