INSERT INTO document_revision_schema_evidence
(revision_id,account_id,principal,operation_id,owner_generation,revision_ordinal,
 root_locator_sha256,fragment_sha256,fragment_size,evidence_codec,evidence_version,evidence_bytes,evidence_sha256)
VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)