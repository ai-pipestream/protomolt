SELECT retain_until>clock_timestamp() AND sealed AND release_xid IS NULL
FROM document_assessment_owners WHERE assessment_id=$1