SELECT a.attempt_id FROM document_part_attempts a WHERE a.attempt_id IN (
 SELECT l.source_id FROM jsonb_to_recordset(CAST($1 AS jsonb)) q(object uuid)
 JOIN repository_physical_locations l ON l.object_id=q.object AND l.source_kind=$2)
ORDER BY a.attempt_id FOR SHARE OF a