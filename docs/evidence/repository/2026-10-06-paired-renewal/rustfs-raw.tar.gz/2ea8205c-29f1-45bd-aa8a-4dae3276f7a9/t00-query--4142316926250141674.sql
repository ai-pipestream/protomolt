UPDATE document_part_attempts SET lease_until=GREATEST(lease_until,clock_timestamp()+($1 * interval '1 millisecond'))
WHERE attempt_id IN ($2)