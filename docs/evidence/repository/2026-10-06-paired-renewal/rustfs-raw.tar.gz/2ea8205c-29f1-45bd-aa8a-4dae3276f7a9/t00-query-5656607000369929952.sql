SELECT count(*),COALESCE(sum(octet_length(evidence_bytes)),$3),count(*) FILTER(WHERE account_id=$1)
FROM document_revision_schema_evidence WHERE revision_id=$2