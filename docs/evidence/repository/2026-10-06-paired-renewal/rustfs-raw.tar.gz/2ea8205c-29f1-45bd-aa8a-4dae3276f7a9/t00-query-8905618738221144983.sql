SELECT command_codec,command_version,command,command_sha256,owner_token,owner_generation,
    lease_until,created_at FROM repository_operations c JOIN repository_operation_owners o
    USING(account_id,principal,operation_id)
WHERE c.account_id=$1 AND c.principal=$2 AND c.operation_id=$3
 FOR UPDATE OF o