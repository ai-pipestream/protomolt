INSERT INTO document_read_pins(pin_id,reader_incarnation,object_id,source_node,source_revision,publication_revision,read_scope)
SELECT q.pin,$1,q.object,$2,$3,$4,$6
FROM jsonb_to_recordset(CAST($5 AS jsonb)) q(pin uuid,object uuid) ORDER BY q.object