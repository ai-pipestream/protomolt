INSERT INTO repository_coordinator_bindings(account_id,principal,operation_id,claim_epoch,claim_token,incarnation)
VALUES($1,$2,$3,$4,$5,$6)