SELECT d.*,d.mutation_revision AS locked_revision
FROM unnest(CAST($1 AS uuid[])) WITH ORDINALITY AS requested(id,position)
JOIN documents d ON d.node_id=requested.id
ORDER BY requested.position FOR UPDATE OF d