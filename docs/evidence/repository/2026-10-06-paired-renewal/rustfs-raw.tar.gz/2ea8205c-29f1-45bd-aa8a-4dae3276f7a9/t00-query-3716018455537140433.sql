SELECT object_id,source_kind,source_id FROM repository_physical_locations
WHERE object_id=ANY(CAST($1 AS uuid[]))