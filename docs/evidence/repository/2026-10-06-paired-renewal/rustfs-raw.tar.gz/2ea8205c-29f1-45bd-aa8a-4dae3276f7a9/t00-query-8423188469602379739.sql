SELECT owner_generation FROM repository_operation_owners
WHERE account_id=$1 AND principal=$2 AND operation_id=$3 FOR UPDATE