SELECT a.size_bytes FROM repository_schema_artifacts a JOIN repository_schema_artifact_claims c
 ON c.account_id=a.account_id AND c.artifact_sha256=a.artifact_sha256
WHERE c.account_id=$1 AND c.principal=$2 AND c.operation_id=$3
 AND c.owner_generation=$4 AND c.artifact_sha256=$5 FOR KEY SHARE OF a,c