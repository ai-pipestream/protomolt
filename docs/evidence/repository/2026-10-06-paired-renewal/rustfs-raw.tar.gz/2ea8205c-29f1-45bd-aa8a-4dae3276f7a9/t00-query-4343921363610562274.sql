INSERT INTO document_part_attempts(attempt_id,node_id,account_id,sampled_revision,backend_generation,
    storage_realm,storage_namespace,planned_count,source_count,lease_token,lease_until,state,
    plan_kind,operation_principal,operation_id,operation_generation,member_id,drive_id)
VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
    clock_timestamp()+($11 * interval $17),$18,$19,
    $12,$13,$14,$15,$16)