SELECT c.policy_revision,p.policy_codec,p.policy_version,p.policy_bytes,p.policy_sha256
FROM document_schema_policy_current c JOIN document_schema_policies p
 ON p.account_id=c.account_id AND p.policy_sha256=c.policy_sha256
WHERE c.account_id=$1