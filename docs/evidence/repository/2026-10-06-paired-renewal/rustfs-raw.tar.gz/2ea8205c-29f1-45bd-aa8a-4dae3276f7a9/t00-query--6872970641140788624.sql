WITH expected AS (
  SELECT * FROM jsonb_to_recordset(CAST($1 AS jsonb)) q(member_id text,node_id uuid,
    sampled_revision bigint,drive_id uuid,backend_generation text,storage_realm text,
    storage_namespace text,upload_count integer,attempt_id uuid)
), actual AS (
  SELECT member_id,node_id,sampled_revision,drive_id,backend_generation,storage_realm,
    storage_namespace,upload_count,attempt_id FROM document_operation_selections
  WHERE account_id=$2 AND principal=$3 AND operation_id=$4 AND owner_generation=$5
)
SELECT NOT EXISTS((SELECT * FROM expected EXCEPT SELECT * FROM actual)
  UNION ALL (SELECT * FROM actual EXCEPT SELECT * FROM expected))