SELECT owner_generation,result_codec,result_version,result_bytes,encode(result_sha256,'hex'),
    recorded_at_epoch_micros,disposition,reason,command_codec,command_version,encode(command_sha256,'hex'),
    assessment_id,manifest_codec,manifest_version,encode(manifest_sha256,'hex'),retain_until_epoch_micros
FROM repository_operation_rejection
WHERE account_id=$1 AND principal=$2 AND operation_id=$3