SELECT attempt_id,node_id,account_id,backend_generation,storage_namespace,storage_realm,
       sampled_revision,lease_token,EXTRACT(EPOCH FROM lease_until),state,planned_count,plan_kind
FROM document_part_attempts WHERE attempt_id=$1
 FOR UPDATE