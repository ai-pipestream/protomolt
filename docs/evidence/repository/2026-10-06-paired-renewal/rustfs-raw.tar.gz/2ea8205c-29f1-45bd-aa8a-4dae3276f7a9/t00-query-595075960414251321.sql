INSERT INTO repository_execution_claims(account_id,principal,operation_id,command_sha256,
    claim_epoch,claim_token,lease_until,fence_epoch,fence_token)
VALUES ($1,$2,$3,$4,$8,$5,clock_timestamp()+($6 * interval $9),$10,$7)
ON CONFLICT(account_id,principal,operation_id) DO NOTHING