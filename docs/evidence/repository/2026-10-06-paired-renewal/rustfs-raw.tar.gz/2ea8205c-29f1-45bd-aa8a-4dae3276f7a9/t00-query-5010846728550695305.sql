SELECT lease_until > clock_timestamp() FROM repository_execution_claims
WHERE account_id=$1 AND principal=$2 AND operation_id=$3