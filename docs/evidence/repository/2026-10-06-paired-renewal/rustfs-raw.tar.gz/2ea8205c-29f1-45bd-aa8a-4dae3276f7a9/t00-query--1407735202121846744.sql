SELECT preparation_bytes,preparation_sha256,owner_nonce,command_sha256 FROM repository_publication_preparations
WHERE account_id=$1 AND principal=$2 AND operation_id=$3 AND predecessor_generation=$4