UPDATE document_part_attempts SET state=$3 WHERE attempt_id=$1 AND state=$4
  AND NOT EXISTS(SELECT $5 FROM document_part_attempt_objects WHERE attempt_id=$2 AND NOT verified)