INSERT INTO document_assessment_owners(assessment_id,account_id,principal,operation_id,owner_generation,
    command_codec,command_version,command_sha256,manifest_bytes,manifest_sha256,expected_slots,expected_artifacts,
    expected_roots,retain_until,creation_xid)
VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15::xid8)