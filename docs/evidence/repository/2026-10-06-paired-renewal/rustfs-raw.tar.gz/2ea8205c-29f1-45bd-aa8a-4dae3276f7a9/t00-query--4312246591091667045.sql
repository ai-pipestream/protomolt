SELECT (SELECT count(*) FROM document_assessment_slots WHERE assessment_id=$1),
    (SELECT count(*) FROM document_assessment_objects WHERE assessment_id=$2),
    (SELECT count(*) FROM repository_object_references WHERE owner_kind=$4 AND owner_id=$3)