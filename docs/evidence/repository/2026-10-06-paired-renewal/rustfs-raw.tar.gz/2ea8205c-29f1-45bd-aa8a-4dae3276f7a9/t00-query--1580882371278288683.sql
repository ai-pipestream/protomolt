SELECT assessment_id,retain_until FROM repository_publication_assessment_starts
WHERE account_id=$1 AND principal=$2 AND operation_id=$3 AND predecessor_generation=$4