SELECT s.member_id,s.revision_ordinal,s.object_id,o.part,o.sub_key,
    l.object_key,o.expected_size,o.expected_sha256,o.provider_version,o.etag,o.content_type,
    l.backend_generation,l.storage_realm,l.storage_namespace
FROM document_assessment_slots s
JOIN document_assessment_objects n ON n.assessment_id=s.assessment_id AND n.object_id=s.object_id
JOIN repository_object_references r ON r.object_id=s.object_id AND r.owner_kind=$2
    AND r.owner_id=s.assessment_id AND r.owner_revision=$3
JOIN repository_object_retention t ON t.object_id=s.object_id AND NOT t.reclaiming
JOIN repository_physical_locations l ON l.object_id=s.object_id AND l.source_kind=$4
JOIN document_part_attempt_objects o ON o.physical_object_id=l.object_id
    AND o.attempt_id=l.source_id AND o.ordinal=l.source_ordinal AND o.verified
    AND o.object_key=l.object_key AND o.storage_realm=l.storage_realm AND o.storage_namespace=l.storage_namespace
JOIN document_part_attempts a ON a.attempt_id=o.attempt_id AND a.state=$5
    AND a.backend_generation=l.backend_generation AND a.storage_realm=l.storage_realm
    AND a.storage_namespace=l.storage_namespace
WHERE s.assessment_id=$1 ORDER BY s.member_id COLLATE "C",s.revision_ordinal LIMIT $6