INSERT INTO document_assessment_slot_snapshots(assessment_id,snapshot_codec,snapshot_version,
    snapshot_bytes,snapshot_sha256) VALUES($1,$2,$3,$4,$5)