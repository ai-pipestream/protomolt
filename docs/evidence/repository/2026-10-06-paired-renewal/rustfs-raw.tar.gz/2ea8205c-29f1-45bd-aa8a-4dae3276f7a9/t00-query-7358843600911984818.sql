INSERT INTO document_revision_publications(revision_id,node_id,publication_revision,body,published_at,native_binding)
SELECT $1,node_id,mutation_revision,document_publication_body(documents),clock_timestamp(),$2
FROM documents WHERE node_id=$3