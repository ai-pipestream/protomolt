SELECT a.operation_id,a.member_id,encode(a.command_sha256,$3),encode(a.policy_sha256,$4),
 o.command_codec,o.command_version,
 CASE WHEN octet_length(o.command) BETWEEN $5 AND $6 THEN o.command END,
 p.policy_codec,p.policy_version,
 CASE WHEN octet_length(p.policy_bytes) BETWEEN $7 AND $8 THEN p.policy_bytes END,
 a.manifest=document_schema_retention_manifest_v1(a.revision_id),
 o.command_sha256=a.command_sha256
FROM document_revision_schema_admissions a
JOIN repository_operations o USING(account_id,principal,operation_id)
JOIN document_schema_policies p ON p.account_id=a.account_id AND p.policy_sha256=a.policy_sha256
WHERE a.revision_id=$1 AND a.account_id=$2