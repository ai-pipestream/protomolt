SELECT member_id,revision_ordinal,encode(root_locator_sha256,$4),encode(fragment_sha256,$5),
    fragment_size,evidence_codec,evidence_version,encode(evidence_sha256,$6),evidence_size,
    CASE WHEN evidence_size BETWEEN $7 AND $8 THEN evidence_bytes END
FROM document_assessment_roots WHERE assessment_id=$1
  AND (SELECT COALESCE(sum(evidence_size),$9) FROM document_assessment_roots WHERE assessment_id=$2)=$3
ORDER BY member_id COLLATE "C",revision_ordinal,root_locator_sha256 LIMIT $10