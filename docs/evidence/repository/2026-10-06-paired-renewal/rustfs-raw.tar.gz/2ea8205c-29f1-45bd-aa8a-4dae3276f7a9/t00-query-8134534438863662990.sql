NOT EXISTS (SELECT 1 FROM repository_operation_owners
                   WHERE account_id=NEW.account_id AND principal=NEW.principal AND operation_id=NEW.operation_id)