WITH snapshots AS MATERIALIZED (
SELECT document_publication_body(d) AS body,document_revision_metadata_v1(d) AS metadata
FROM jsonb_populate_record($25::documents,jsonb_build_object(
  $26,CAST($1 AS uuid),$27,CAST($2 AS text),
  $28,CAST($3 AS text),$29,CAST($4 AS text),$30,CAST($5 AS text),
  $31,CAST($6 AS text),$32,CAST($7 AS text),$33,CAST($8 AS text),
  $34,CAST($9 AS text),$35,CAST($10 AS bigint),$36,CAST($11 AS text),
  $37,CAST($12 AS jsonb),$38,CAST($13 AS text),$39,CAST($14 AS text),
  $40,CAST($15 AS text),$41,CAST($16 AS text),
  $42,CAST($17 AS text),$43,CAST($18 AS text),$44,CAST($19 AS jsonb),
  $45,CAST($20 AS boolean),$46,CAST($21 AS text),
  $47,CAST($22 AS text),$48,CAST($23 AS timestamptz),$49,CAST($24 AS timestamptz)
)) d)
SELECT CASE WHEN octet_length(body::text)<=$50 THEN body::text END,
       CASE WHEN octet_length(metadata::text)<=$51 THEN metadata::text END FROM snapshots