SELECT a.size_bytes FROM document_assessment_artifacts r JOIN repository_schema_artifacts a USING(account_id,artifact_sha256)
WHERE r.assessment_id=$1 AND r.account_id=$2 LIMIT $3