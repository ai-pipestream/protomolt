INSERT INTO repository_publication_modes(account_id,principal,operation_id,predecessor_generation,owner_nonce,modes)
VALUES ($1,$2,$3,$4,$5,CAST($6 AS jsonb))
ON CONFLICT(account_id,principal,operation_id,predecessor_generation) DO NOTHING