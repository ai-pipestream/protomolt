INSERT INTO repository_publication_assessment_starts(account_id,principal,operation_id,predecessor_generation,
  owner_nonce,command_sha256,assessment_id,retention_micros,retain_until)
VALUES ($1,$2,$3,$4,$5,$6,$7,$8,clock_timestamp())
ON CONFLICT(account_id,principal,operation_id,predecessor_generation) DO NOTHING