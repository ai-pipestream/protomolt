SELECT session_id FROM document_assessment_read_sessions
WHERE session_id=$1 AND reader_incarnation=$2 AND assessment_id=$3
    AND release_xid IS NULL FOR SHARE