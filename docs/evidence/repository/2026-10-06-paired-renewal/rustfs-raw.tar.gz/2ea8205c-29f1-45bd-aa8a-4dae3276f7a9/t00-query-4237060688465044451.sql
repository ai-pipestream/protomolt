SELECT claim_token,incarnation FROM repository_coordinator_bindings
WHERE account_id=$1 AND principal=$2 AND operation_id=$3 AND claim_epoch=$4