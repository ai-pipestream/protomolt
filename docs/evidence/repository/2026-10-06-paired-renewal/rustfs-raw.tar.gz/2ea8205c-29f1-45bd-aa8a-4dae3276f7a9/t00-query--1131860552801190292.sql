INSERT INTO repository_operations(account_id,principal,operation_id,command_codec,command_version,
    command,command_sha256)
VALUES ($1,$2,$3,$4,$5,$6,$7)
ON CONFLICT(account_id,principal,operation_id) DO NOTHING