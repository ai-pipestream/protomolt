INSERT INTO document_revision_schema_admissions(revision_id,account_id,principal,operation_id,
 owner_generation,member_id,node_id,selection_revision,command_sha256,policy_revision,policy_sha256,
 decision,body,metadata,manifest,container_type_url_sha256,container_descriptor_sha256)
VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,
 $10,$11,$12,CAST($13 AS jsonb),CAST($14 AS jsonb),CAST($15 AS jsonb),$16,$17)