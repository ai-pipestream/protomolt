SELECT p.command_sha256,a.owner_nonce=p.owner_nonce AND a.preparation_sha256=p.preparation_sha256,
  CASE WHEN octet_length(p.command_bytes)<=$4 THEN p.command_bytes END
FROM repository_publication_abandonments a
JOIN repository_publication_preparations p USING(account_id,principal,operation_id,predecessor_generation)
WHERE a.account_id=$1 AND a.principal=$2 AND a.operation_id=$3