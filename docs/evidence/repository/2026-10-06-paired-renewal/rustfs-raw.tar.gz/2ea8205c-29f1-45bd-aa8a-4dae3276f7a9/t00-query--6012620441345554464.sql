INSERT INTO document_revision_schema_artifacts
(revision_id,account_id,principal,operation_id,owner_generation,artifact_sha256)
VALUES($1,$2,$3,$4,$5,$6)