UPDATE document_part_attempt_objects p SET verified=true,provider_version=q.version,etag=q.etag
FROM jsonb_to_recordset(CAST($1 AS jsonb)) q(key text,size bigint,sha256 text,content_type text,version text,etag text)
WHERE p.attempt_id=$2 AND p.object_key=q.key AND p.expected_size=q.size
  AND p.expected_sha256=q.sha256 AND p.content_type=q.content_type
  AND (NOT p.verified OR (p.provider_version IS NOT DISTINCT FROM q.version AND p.etag IS NOT DISTINCT FROM q.etag))