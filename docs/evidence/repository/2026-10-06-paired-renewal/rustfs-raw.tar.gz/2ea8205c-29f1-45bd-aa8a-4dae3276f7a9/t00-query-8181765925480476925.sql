INSERT INTO document_revision_current(node_id,revision_id) VALUES($1,$2)
ON CONFLICT(node_id) DO UPDATE SET revision_id=EXCLUDED.revision_id