SELECT owner_token,owner_generation,lease_until FROM repository_operation_owners
WHERE account_id=$1 AND principal=$2 AND operation_id=$3
 FOR UPDATE