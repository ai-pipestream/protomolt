SELECT count(*)=$1 AND bool_and(state=$3) AND min(lease_until)>clock_timestamp()
FROM document_part_attempts WHERE attempt_id IN ($2)