INSERT INTO repository_operation_success(account_id,principal,operation_id,owner_generation,
    command_codec,command_version,command_sha256,result_codec,result_version,result_bytes,result_sha256,member_count)
SELECT account_id,principal,operation_id,$1,command_codec,command_version,command_sha256,
    $2,$3,$4,$5,$6 FROM repository_operations
WHERE account_id=$7 AND principal=$8 AND operation_id=$9