SELECT owner_nonce FROM repository_publication_modes
WHERE account_id=$1 AND principal=$2 AND operation_id=$3 AND predecessor_generation=$4 FOR UPDATE