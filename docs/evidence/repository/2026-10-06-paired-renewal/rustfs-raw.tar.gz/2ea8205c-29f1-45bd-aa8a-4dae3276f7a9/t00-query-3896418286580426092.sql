SELECT c.revision_id FROM document_revision_current c
WHERE c.node_id=ANY(CAST($1 AS uuid[])) ORDER BY c.node_id FOR UPDATE OF c