SELECT command_sha256,claim_epoch,claim_token,lease_until FROM repository_execution_claims
WHERE account_id=$1 AND principal=$2 AND operation_id=$3 FOR UPDATE