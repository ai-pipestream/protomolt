SELECT count(*),count(a.artifact_sha256),COALESCE(sum(octet_length(a.artifact_bytes)),$3)
FROM document_revision_schema_artifacts r LEFT JOIN repository_schema_artifacts a
 ON a.account_id=r.account_id AND a.account_id=$1 AND a.artifact_sha256=r.artifact_sha256
WHERE r.revision_id=$2