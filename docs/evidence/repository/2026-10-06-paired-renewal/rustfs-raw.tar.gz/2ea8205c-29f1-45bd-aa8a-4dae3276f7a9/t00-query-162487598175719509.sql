INSERT INTO repository_publication_preparations(account_id,principal,operation_id,predecessor_generation,
  owner_nonce,command_codec,command_version,command_bytes,command_sha256,preparation_bytes,preparation_sha256)
VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
ON CONFLICT(account_id,principal,operation_id,predecessor_generation) DO NOTHING