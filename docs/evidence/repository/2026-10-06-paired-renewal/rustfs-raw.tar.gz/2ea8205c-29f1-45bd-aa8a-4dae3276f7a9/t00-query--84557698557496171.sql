NOT EXISTS(SELECT 1 FROM document_operation_selection_current
  WHERE account_id=NEW.account_id AND principal=NEW.principal AND operation_id=NEW.operation_id
   AND owner_generation=NEW.owner_generation AND member_id=NEW.member_id AND selection_revision>=NEW.selection_revision)