SELECT r.revision_ordinal,r.part,r.sub_key,l.object_key,o.expected_size,o.expected_sha256,
 o.provider_version,o.etag,l.backend_generation,l.storage_namespace,l.storage_realm,o.content_type,l.object_id
FROM document_revision_parts r
JOIN repository_physical_locations l ON l.object_id=r.object_id AND l.source_kind=$3
JOIN document_part_attempt_objects o ON o.physical_object_id=l.object_id
 AND o.attempt_id=l.source_id AND o.ordinal=l.source_ordinal AND o.verified
 AND o.part=r.part AND o.sub_key=r.sub_key AND o.object_key=l.object_key
 AND o.storage_namespace=l.storage_namespace AND o.storage_realm=l.storage_realm
JOIN document_part_attempts a ON a.attempt_id=o.attempt_id AND a.state=$4
 AND a.backend_generation=l.backend_generation AND a.storage_realm=l.storage_realm
WHERE r.revision_id=$1 ORDER BY r.revision_ordinal fetch first $2 rows only