SELECT attempt_id FROM document_part_attempts
WHERE attempt_id=ANY(CAST($1 AS uuid[])) ORDER BY attempt_id FOR UPDATE