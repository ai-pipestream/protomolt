SELECT CASE WHEN octet_length(policy_bytes)=$1 THEN policy_bytes END FROM document_schema_policies
WHERE account_id=$2 AND encode(policy_sha256,'hex')=$3