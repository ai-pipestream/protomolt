SELECT policy_codec,policy_version,octet_length(policy_bytes) FROM document_schema_policies
WHERE account_id=$1 AND encode(policy_sha256,'hex')=$2